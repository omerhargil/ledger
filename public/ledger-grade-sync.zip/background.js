// Ledger Importer: background worker.
//
// When the Ledger page asks for grades, this reads them straight from Aeries using the Aeries session your browser
// already has (through a hidden "offscreen" page that can parse HTML). No tab, no page flipping, a few seconds.
// If Aeries has logged you out, or direct reading doesn't work on your portal, it falls back to opening Aeries in a
// tab: you sign in there, and it carries on. It never sees or stores your password.
//
// Two kinds of request:
//  - manual: the person clicked something. Shows progress, and opens the sign-in tab if needed.
//  - silent: Ledger's quiet 10-second check. One cheap request; a full read only when a grade changed.
//    It never opens tabs and says nothing unless something is wrong.

const HOST_RE = /^[a-z0-9-]+(\.[a-z0-9-]+)*\.aeries\.net$/i;
const MAX_GOTO = 6; // times in a row Aeries may send the tab somewhere other than the gradebook
const MAX_HELLOS = 4; // times the gradebook may (re)load while it is being read in a tab
const SILENT_FULL_EVERY = 120000; // even if nothing seems to have changed, re-read every 2 minutes
const SILENT_NOPROBE_EVERY = 30000; // if the cheap check isn't possible on this portal, re-read every 30 seconds

// reader.js (also used by the page scripts) has the snapshot helpers. In the worker it is loaded with importScripts.
let snapshotOfFn;
let diffSnapshotsFn;
if (typeof importScripts === "function") {
  importScripts("reader.js");
  snapshotOfFn = snapshotOf;
  diffSnapshotsFn = diffSnapshots;
} else if (typeof require === "function") {
  const R = require("./reader.js");
  snapshotOfFn = R.snapshotOf;
  diffSnapshotsFn = R.diffSnapshots;
}

// Portals live in a folder on the host: usually /student/, but some districts use /Student/ or /parent/ and so on.
const BASE_RE = /^\/[A-Za-z0-9_.\-]+(\/[A-Za-z0-9_.\-]+)*\/$/;
const normBase = (b) => (typeof b === "string" && b.length <= 80 && BASE_RE.test(b) && !/\.\./.test(b) ? b : "/student/");
const gradebookUrl = (host, base) => "https://" + host + normBase(base) + "GradebookDetails.aspx";
const baseOf = (host, base) => "https://" + host + normBase(base);
const pathOf = (url) => { try { return new URL(url).pathname; } catch (e) { return ""; } };

// What should we do now that this job's tab finished loading this URL?
function decide(url, host, base) {
  let u;
  try { u = new URL(url); } catch (e) { return "wait"; }
  if (u.hostname.toLowerCase() !== String(host).toLowerCase()) return "wait"; // e.g. Google sign-in pages
  const p = u.pathname.toLowerCase();
  if (/login/.test(p)) return "login";
  if (/\/gradebookdetails\.aspx$/.test(p)) return "gradebook";
  if (p.startsWith(normBase(base).toLowerCase())) return "goto";
  return "wait";
}

if (typeof module !== "undefined" && module.exports) module.exports = { decide, HOST_RE, gradebookUrl, baseOf, pathOf, normBase };

if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.onMessage) {
  // MV3 workers sleep between events, so state lives in session storage, not in variables.
  const getJobs = async () => ((await chrome.storage.session.get("jobs")).jobs) || {};
  const setJobs = (jobs) => chrome.storage.session.set({ jobs });
  const getSigs = async () => ((await chrome.storage.session.get("sigs")).sigs) || {};
  const rememberFull = async (host, sig) => {
    const sigs = await getSigs();
    sigs[host] = { sig: sig || null, fullAt: Date.now() };
    await chrome.storage.session.set({ sigs });
  };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const withTimeout = (p, ms) => new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(new Error("timed out")), ms);
    p.then((v) => { clearTimeout(t); resolve(v); }, (e) => { clearTimeout(t); reject(e); });
  });
  const tell = (tabId, m) => { try { return Promise.resolve(chrome.tabs.sendMessage(tabId, m)).catch(() => {}); } catch (e) { return Promise.resolve(); } };
  const status = (phase, detail) => ({ type: "ledger:ext-status", phase, detail: detail || "" });
  const closeQuiet = (tabId) => { try { return Promise.resolve(chrome.tabs.remove(tabId)).catch(() => {}); } catch (e) { return Promise.resolve(); } };

  // Every handler reads and writes shared state, so run them one at a time.
  let queue = Promise.resolve();
  const serial = (fn) => { const p = queue.then(fn); queue = p.catch(() => {}); return p; };

  // --- the hidden reader page ----------------------------------------------------

  async function ensureOffscreen() {
    if (!chrome.offscreen) throw new Error("this browser has no offscreen pages");
    try {
      await chrome.offscreen.createDocument({ url: "offscreen.html", reasons: ["DOM_PARSER"], justification: "Parse Aeries gradebook pages" });
    } catch (e) {
      if (!/single offscreen|already|exists/i.test(String((e && e.message) || e))) throw e; // it's already open: fine
    }
  }

  async function offscreenCall(msg) {
    try {
      await ensureOffscreen();
      const r = await withTimeout(Promise.resolve(chrome.runtime.sendMessage(Object.assign({ target: "offscreen" }, msg))), 60000);
      return r || { ok: false, reason: "fail", detail: "no answer from the reader page" };
    } catch (e) {
      return { ok: false, reason: "fail", detail: String((e && e.message) || e).slice(0, 200) };
    }
  }
  // The portal folder for each host is remembered (Ledger sends it with every request).
  const rememberBase = async (host, base) => {
    const b = normBase(base);
    const cur = ((await chrome.storage.local.get("bases")).bases) || {};
    if (cur[host] !== b) { cur[host] = b; await chrome.storage.local.set({ bases: cur }); }
    return b;
  };
  const baseFor = async (host) => normBase((((await chrome.storage.local.get("bases")).bases) || {})[host]);
  const fastRead = async (host) => offscreenCall({ type: "offscreen:read", base: baseOf(host, await baseFor(host)) });
  const probe = async (host) => offscreenCall({ type: "offscreen:probe", base: baseOf(host, await baseFor(host)) });

  const resultMsg = (r) => ({ type: "ledger:ext-result", payload: r.payload, diag: r.diag });

  // --- jobs (the tab method) -------------------------------------------------------

  async function endJob(auxId, jobs, job, { refocus }) {
    delete jobs[auxId];
    await setJobs(jobs);
    await closeQuiet(Number(auxId));
    if (refocus && job.loginShown) {
      try { await chrome.tabs.update(job.ledgerTabId, { active: true }); } catch (e) { /* Ledger tab is gone */ }
    }
  }

  async function fail(auxId, jobs, job, message) {
    await tell(job.ledgerTabId, status("error", message));
    await endJob(auxId, jobs, job, { refocus: true });
  }

  async function openJobTab(host, ledgerTabId) {
    const jobs = await getJobs();
    for (const id of Object.keys(jobs)) {
      if (jobs[id].ledgerTabId === ledgerTabId) { await closeQuiet(Number(id)); delete jobs[id]; } // replace an older job
    }
    const base = await baseFor(host);
    const tab = await chrome.tabs.create({ url: gradebookUrl(host, base), active: false });
    jobs[tab.id] = { ledgerTabId, host, base, goto: 0, hellos: 0, loginShown: false, triedFast: false, trail: [] };
    await setJobs(jobs);
  }

  // --- requests from Ledger ---------------------------------------------------------

  async function manualRefresh(host, ledgerTabId) {
    await tell(ledgerTabId, status("starting"));
    await tell(ledgerTabId, status("reading", "Reading your grades…"));
    const r = await fastRead(host);
    if (r.ok) {
      await rememberFull(host, null);
      await tell(ledgerTabId, resultMsg(r));
      return;
    }
    // Logged out, or direct reading isn't possible here: use a tab (sign-in, or reading page by page).
    await openJobTab(host, ledgerTabId);
  }

  async function silentRefresh(host, ledgerTabId, force) {
    const now = Date.now();
    const rec = (await getSigs())[host] || {};
    const pr = await probe(host);
    if (!pr.ok) return tell(ledgerTabId, status(pr.reason === "login" ? "signedout" : "silent-error", pr.detail));
    const hasSig = typeof pr.sig === "string" && pr.sig.length > 0;
    const fullAge = now - (rec.fullAt || 0);
    const due = force || (hasSig ? (pr.sig !== rec.sig || fullAge >= SILENT_FULL_EVERY) : fullAge >= SILENT_NOPROBE_EVERY);
    if (!due) return tell(ledgerTabId, status("unchanged"));
    const r = await fastRead(host);
    if (r.ok) {
      await rememberFull(host, hasSig ? pr.sig : null);
      return tell(ledgerTabId, resultMsg(r));
    }
    return tell(ledgerTabId, status(r.reason === "login" ? "signedout" : "silent-error", r.detail));
  }

  async function start(host, ledgerTabId, mode, force, base) {
    if (ledgerTabId == null) return;
    await chrome.storage.session.set({ ledgerSeen: Date.now() }); // Ledger is open (so desktop alerts can stay quiet)
    const silent = mode === "silent";
    if (HOST_RE.test(host)) await rememberBase(host, base);
    if (!HOST_RE.test(host)) {
      await tell(ledgerTabId, status(silent ? "silent-error" : "error", "Ledger can only read aeries.net portals for now (" + host + ")."));
      return;
    }
    return silent ? silentRefresh(host, ledgerTabId, force) : manualRefresh(host, ledgerTabId);
  }

  async function cancelFor(ledgerTabId) {
    const jobs = await getJobs();
    for (const id of Object.keys(jobs)) {
      if (jobs[id].ledgerTabId === ledgerTabId) await endJob(id, jobs, jobs[id], { refocus: false });
    }
  }

  // --- grade alerts (opt-in) ------------------------------------------------------
  // Every 2 minutes: one cheap request. Only if a grade on the dashboard changed is everything read, compared with
  // the last read, and a desktop notification shown for what is new. If Ledger is open and in front, you can see the
  // changes there, so no notification is shown (the comparison point is still updated).

  const ALERT_ALARM = "ledger-alerts";
  const ALERT_EVERY_MIN = 2;
  const ALERT_FRESH_MS = 600000; // even without a change signal, read in full at least every 10 minutes
  const LEDGER_SEEN_MS = 30000;

  const notify = (id, title, message) => {
    try {
      return Promise.resolve(chrome.notifications.create(id, {
        type: "basic", iconUrl: chrome.runtime.getURL("icons/icon128.png"), title, message, priority: 1,
      })).catch(() => {});
    } catch (e) { return Promise.resolve(); }
  };

  async function ensureAlarm() {
    if (!chrome.alarms) return;
    const existing = await chrome.alarms.get(ALERT_ALARM);
    if (!existing) await chrome.alarms.create(ALERT_ALARM, { periodInMinutes: ALERT_EVERY_MIN, delayInMinutes: ALERT_EVERY_MIN });
  }

  async function notifyChanges(changes, now) {
    const fmt = (c) => c.cls + ": " + c.name + " " + c.earned + "/" + c.possible;
    if (changes.length === 1) await notify("ledger-" + now, changes[0].kind === "new" ? "New grade" : "Grade changed", fmt(changes[0]));
    else {
      const shown = changes.slice(0, 3).map(fmt).join("\n");
      await notify("ledger-" + now, changes.length + " grade updates", shown + (changes.length > 3 ? "\n+" + (changes.length - 3) + " more" : ""));
    }
  }

  async function alertTick() {
    const { alerts, alertState } = await chrome.storage.local.get(["alerts", "alertState"]);
    if (!alerts || !alerts.on) { if (chrome.alarms) await chrome.alarms.clear(ALERT_ALARM); return; }
    const host = alerts.host;
    const st = alertState || {};
    const now = Date.now();
    const signedOut = async () => {
      if (st.signedOutShown) return;
      await notify("ledger-signedout", "Aeries signed you out", "Open Ledger and click Sign in to keep getting grade alerts.");
      await chrome.storage.local.set({ alertState: { ...st, signedOutShown: true } });
    };
    const pr = await probe(host);
    if (!pr.ok) { if (pr.reason === "login") await signedOut(); return; }
    const hasSig = typeof pr.sig === "string" && pr.sig.length > 0;
    if (st.snap && hasSig && pr.sig === st.sig && now - (st.fullAt || 0) < ALERT_FRESH_MS) return; // nothing changed
    const r = await fastRead(host);
    if (!r.ok) { if (r.reason === "login") await signedOut(); return; }
    const snap = snapshotOfFn(r.payload);
    if (st.snap) {
      const changes = diffSnapshotsFn(st.snap, snap);
      const seen = ((await chrome.storage.session.get("ledgerSeen")).ledgerSeen) || 0;
      if (changes.length && now - seen > LEDGER_SEEN_MS) await notifyChanges(changes, now);
    }
    await chrome.storage.local.set({ alertState: { sig: hasSig ? pr.sig : null, snap, fullAt: now, signedOutShown: false } });
  }

  async function setAlerts(host, on, base) {
    if (!on || !HOST_RE.test(host)) {
      await chrome.storage.local.set({ alerts: { on: false, host: "" } });
      await chrome.storage.local.remove("alertState");
      if (chrome.alarms) await chrome.alarms.clear(ALERT_ALARM);
      return;
    }
    await rememberBase(host, base);
    const cur = (await chrome.storage.local.get("alerts")).alerts;
    if (cur && cur.on && cur.host === host) { await ensureAlarm(); return; } // Ledger says this on every page load: no reset
    await chrome.storage.local.set({ alerts: { on: true, host } });
    await chrome.storage.local.remove("alertState");
    await ensureAlarm();
    await alertTick(); // the first read is the comparison point: it never notifies
  }

  async function handle(msg, sender) {
    if (!msg || typeof msg.type !== "string") return undefined;
    const tabId = sender && sender.tab ? sender.tab.id : undefined;
    if (msg.type === "ledger:refresh") return start(String(msg.host || ""), tabId, msg.mode === "silent" ? "silent" : "manual", msg.force === true, msg.base);
    if (msg.type === "ledger:cancel") return cancelFor(tabId);
    if (msg.type === "ledger:alerts") return setAlerts(String(msg.host || ""), msg.on === true, msg.base);

    let jobs = await getJobs();

    // A page script on an Aeries gradebook asks: "should I read by myself?"
    if (msg.type === "ledger:aux-hello") {
      if (tabId != null && !jobs[tabId]) { await sleep(400); jobs = await getJobs(); } // the job may still be being saved
      const job = tabId != null ? jobs[tabId] : undefined;
      if (!job) return { auto: false }; // an ordinary tab the person is using
      job.hellos = (job.hellos || 0) + 1;
      if (job.hellos > MAX_HELLOS) {
        await fail(tabId, jobs, job, "Aeries kept reloading the gradebook while Ledger was reading it. Try again.");
        return { auto: false };
      }
      await setJobs(jobs);
      return { auto: true };
    }

    // Everything below must come from a tab this worker opened.
    const job = tabId != null ? jobs[tabId] : undefined;
    if (!job) return undefined;
    if (msg.type === "ledger:aux-progress") {
      await tell(job.ledgerTabId, status("reading", msg.n ? "Reading class " + Number(msg.i) + " of " + Number(msg.n) + "…" : "Reading your grades…"));
    } else if (msg.type === "ledger:aux-grades") {
      await tell(job.ledgerTabId, { type: "ledger:ext-result", payload: msg.payload, diag: msg.diag });
      await endJob(tabId, jobs, job, { refocus: true });
    } else if (msg.type === "ledger:aux-error") {
      await fail(tabId, jobs, job, String(msg.message || "Something went wrong reading your grades.").slice(0, 200));
    }
    return undefined;
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.target === "offscreen") return false; // meant for the reader page, not for us
    serial(() => handle(msg, sender)).then((r) => sendResponse(r || { ok: true }), () => sendResponse({ ok: false }));
    return true;
  });

  chrome.tabs.onUpdated.addListener((tabId, info, tab) => serial(async () => {
    if (info.status !== "complete") return;
    const jobs = await getJobs();
    const job = jobs[tabId];
    if (!job) return;
    const url = (tab && tab.url) || "";
    const act = decide(url, job.host, job.base);
    if (act !== "wait") job.trail = (job.trail || []).concat(pathOf(url)).slice(-6); // for the error message only

    if (act === "login") {
      const firstTime = !job.loginShown;
      job.loginShown = true;
      await setJobs(jobs);
      if (firstTime) {
        try {
          await chrome.tabs.update(tabId, { active: true });
          if (tab && tab.windowId != null) await chrome.windows.update(tab.windowId, { focused: true });
        } catch (e) { /* best effort */ }
      }
      await tell(job.ledgerTabId, status("login"));
    } else if (act === "goto") {
      // Signed in (we are past the login page). Now that the session is good, try the fast way once.
      if (job.loginShown && !job.triedFast) {
        job.triedFast = true;
        await setJobs(jobs);
        await tell(job.ledgerTabId, status("reading", "Reading your grades…"));
        const r = await fastRead(job.host);
        if (r.ok) {
          await rememberFull(job.host, null);
          await tell(job.ledgerTabId, resultMsg(r));
          await endJob(tabId, await getJobs(), job, { refocus: true });
          return;
        }
      }
      job.goto = (job.goto || 0) + 1;
      if (job.goto > MAX_GOTO) {
        await fail(tabId, jobs, job, "Aeries kept sending the page somewhere else (" + job.trail.join(" → ") + "). Try again.");
        return;
      }
      await setJobs(jobs);
      await chrome.tabs.update(tabId, { url: gradebookUrl(job.host, job.base) });
    } else if (act === "gradebook") {
      job.goto = 0; // we got there, so earlier detours don't count
      await setJobs(jobs);
      await tell(job.ledgerTabId, status("reading", "Reading your grades…"));
    }
  }));

  if (chrome.alarms) {
    chrome.alarms.onAlarm.addListener((a) => { if (a && a.name === ALERT_ALARM) serial(alertTick).catch(() => {}); });
    // the alarm can be lost when the extension is reloaded: put it back if alerts are on
    serial(async () => { const { alerts } = await chrome.storage.local.get("alerts"); if (alerts && alerts.on) await ensureAlarm(); }).catch(() => {});
  }

  chrome.tabs.onRemoved.addListener((tabId) => serial(async () => {
    const jobs = await getJobs();
    if (jobs[tabId]) { // the Aeries tab was closed before it finished
      const job = jobs[tabId];
      delete jobs[tabId];
      await setJobs(jobs);
      await tell(job.ledgerTabId, status("error", "The Aeries tab was closed before your grades were read."));
      return;
    }
    for (const id of Object.keys(jobs)) { // the Ledger tab was closed: nobody is waiting any more
      if (jobs[id].ledgerTabId === tabId) { delete jobs[id]; await setJobs(jobs); await closeQuiet(Number(id)); }
    }
  }));
}
