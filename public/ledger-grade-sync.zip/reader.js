// Ledger Importer: shared reader.
// Reads class names, teachers, grade categories and weights, and assignment names and scores from an Aeries
// Gradebook Details page. It never looks at your name, ID numbers, birthdate or contact details.
//
// Every function that reads a page takes that page's document. So the same code can read the live page you
// are looking at (content.js) or a gradebook page fetched and parsed in the background (offscreen.js).

// ---------------------------------------------------------------------------
// Pure helpers (no page access, so they can be tested on their own)
// ---------------------------------------------------------------------------

const clean = (s) => String(s == null ? "" : s).replace(/\s+/g, " ").trim();

const num = (s) => {
  const t = clean(s).replace(/[%,]/g, "");
  if (t === "") return NaN;
  const n = Number(t);
  return Number.isFinite(n) ? n : NaN;
};

// "08/25/2026" -> "2026-08-25" (null if it isn't a date)
function parseUsDate(text) {
  const m = /(\d{1,2})\/(\d{1,2})\/(\d{4})/.exec(text || "");
  if (!m) return null;
  const mo = +m[1], d = +m[2];
  if (mo < 1 || mo > 12 || d < 1 || d > 31) return null;
  return m[3] + "-" + String(mo).padStart(2, "0") + "-" + String(d).padStart(2, "0");
}

// The date an assignment belongs to on a timeline: its due date, else when it was completed, else when it was assigned.
function dueOf(cardText) {
  const t = String(cardText || "");
  for (const label of ["Due Date:", "Date Completed:", "Date Assigned:"]) {
    const i = t.indexOf(label);
    if (i < 0) continue;
    const d = parseUsDate(t.slice(i + label.length, i + label.length + 18));
    if (d) return d;
  }
  return null;
}

// "1- AP Seminar- Fall 8/10/2026 - 12/18/2026*"  ->  { period, name, term }
function parseOption(text) {
  const t = clean(text);
  const m = t.match(
    /^(\d+)\s*-\s*(.+?)\s*-\s*([A-Za-z0-9 ]+?)\s+(\d{1,2}\/\d{1,2}\/\d{4})\s*-\s*(\d{1,2}\/\d{1,2}\/\d{4})\s*\*?$/
  );
  return m
    ? { period: m[1], name: clean(m[2]), term: clean(m[3]), start: parseUsDate(m[4]), end: parseUsDate(m[5]) }
    : { period: "", name: t.replace(/\*$/, ""), term: "", start: null, end: null };
}

function levelFor(name) {
  if (/\bAP\b/i.test(name)) return "AP";
  if (/\b(H|Hon|Honors)\b/i.test(name)) return "Honors";
  return "Regular";
}

// "Lastname, Firstname  first.last@school.org"  ->  "Firstname Lastname"
function teacherName(raw) {
  const t = clean(String(raw || "").replace(/\S+@\S+/g, ""));
  const m = t.match(/^([^,]+),\s*(.+)$/);
  return m ? clean(m[2] + " " + m[1]) : t;
}

// Some classes grade on a point scale (scores like "STR(5) / 0", class mark an average such as 5.00).
// Aeries doesn't say what the top score is, so Ledger assumes this and warns about it.
const STANDARDS_SCALE = 5;

// Aeries writes scores like "9", "A+(10)" (letter plus points) or "STR(5)" (point scale), and "" when not scored.
function parseScore(earnedText, possibleText) {
  const e = clean(earnedText);
  const p = num(possibleText);
  if (!Number.isFinite(p)) return { kind: "bad" };
  const paren = e.match(/\((-?\d+(?:\.\d+)?)\)/);
  const earned = paren ? Number(paren[1]) : num(e);
  if (Number.isFinite(earned)) {
    if (p > 0) return { kind: "normal", earned, possible: p };
    return paren ? { kind: "standards", earned } : { kind: "bad" };
  }
  // blank, or text such as "M" or "EX": not a number, so it is up to the grade math whether it counts
  return p > 0 ? { kind: "blank", possible: p } : { kind: "bad" };
}

// Same math as Ledger: each category is earned/possible, weights renormalized over categories that have scores.
function percentOf(categories, items) {
  let used = 0;
  let sum = 0;
  for (const c of categories) {
    const xs = items.filter((a) => a.category === c.name && a.possible > 0);
    if (!xs.length) continue;
    const e = xs.reduce((t, a) => t + a.earned, 0);
    const q = xs.reduce((t, a) => t + a.possible, 0);
    if (q > 0) { sum += (e / q) * 100 * c.weight; used += c.weight; }
  }
  return used > 0 ? sum / used : null;
}

// Classes marked with "*" in Aeries' class list apply a minimum and maximum score to every assignment
// (the page says e.g. "Min Score threshold is 50% and Max Score threshold is 100%"). Mirror that.
function applyScale(items, scale) {
  if (!scale) return { items, changed: 0 };
  let changed = 0;
  const out = items.map((a) => {
    const lo = (a.possible * scale.min) / 100;
    const hi = (a.possible * scale.max) / 100;
    const e = Math.min(Math.max(a.earned, lo), hi);
    if (Math.abs(e - a.earned) > 1e-9) { changed++; return { ...a, earned: Math.round(e * 1000) / 1000 }; }
    return a;
  });
  return { items: out, changed };
}

// Unscored assignments sometimes count in Aeries and sometimes don't (and in a "*" class a missing one counts
// at the minimum score, not 0). Rather than guess the rule, try each reading and keep the one that reproduces
// the percentage Aeries reports (fewest counted wins ties).
function pickItems(categories, items, blanks, reported, scale) {
  const floorOf = (b) => (scale ? Math.round(((b.possible * scale.min) / 100) * 1000) / 1000 : 0);
  const counted = (list) => list.map((b) => ({ category: b.category, name: b.name, earned: floorOf(b), possible: b.possible, due: b.due || null }));
  const done = blanks.filter((b) => b.complete);
  const variants = [
    { used: "graded only", list: items, zeros: 0 },
    { used: "completed blanks counted", list: items.concat(counted(done)), zeros: done.length },
    { used: "all blanks counted", list: items.concat(counted(blanks)), zeros: blanks.length },
  ];
  if (reported == null || !categories.length || !blanks.length) return variants[0];
  let best = null;
  for (const v of variants) {
    const pct = percentOf(categories, v.list);
    if (pct == null) continue;
    const d = Math.abs(pct - reported);
    if (!best || d < best.d - 0.05) best = { ...v, d };
  }
  return best || variants[0];
}

function buildClass({ option, teacher, assignments, categories, total, notes, marks, pending }) {
  const meta = parseOption(option);
  const warnings = [];
  const reported = total && Number.isFinite(total.percent) ? total.percent : null;
  let cats = categories.map((c) => ({ name: c.name, weight: c.weight }));
  const used = [...new Set(assignments.map((a) => a.category))];

  if (!assignments.length) {
    warnings.push(
      reported != null
        ? "Aeries shows " + reported + "% for this class, but its assignments couldn't be read. Try refreshing in a minute."
        : "Nothing to import for this class. It may use a different grading style."
    );
  }

  if (!cats.length) {
    cats = used.map((n) => ({ name: n, weight: Math.round(10000 / used.length) / 100 }));
    if (used.length) {
      warnings.push("Couldn't find category weights for this class, so they were split evenly. Check them against Aeries.");
    }
  } else {
    const known = new Set(cats.map((c) => c.name));
    for (const n of used) {
      if (!known.has(n)) {
        cats.push({ name: n, weight: 0 });
        warnings.push('No weight found for "' + n + '", so it counts as 0%.');
      }
    }
  }

  return {
    period: meta.period,
    name: meta.name,
    term: meta.term,
    teacher: teacherName(teacher),
    level: levelFor(meta.name),
    categories: cats,
    assignments,
    reportedPercent: reported,
    reportedMark: total && /^[A-F][+-]?$/.test(total.mark || "") ? total.mark : null, // the letter Aeries shows for the class
    marks: marks || [], // (percent, letter) pairs Aeries gave for this class: its categories and its total
    termStart: meta.start, // from the class list: "8/10/2026 - 12/18/2026"
    termEnd: meta.end,
    pending: (pending || []).slice(0, 60), // assignments with no score yet: upcoming, missing, or waiting to be graded
    warnings: warnings.concat(notes || []),
  };
}

// ---------------------------------------------------------------------------
// Reading a rendered gradebook page
// ---------------------------------------------------------------------------

const FLAG_WORDS = ["missing", "excused", "exempt", "incomplete", "not graded", "extra credit", "dropped", "pending", "late", "zero"];
const CLASS_SELECT = 'select[id$="_dlGN"]';
const classesOf = (el) => (el.getAttribute("class") || "").split(/\s+/).filter(Boolean);
const cardCount = (doc) => doc.querySelectorAll(".GradebookDetailsTable .Card").length;

function classOptions(doc) {
  const sel = doc.querySelector(CLASS_SELECT);
  return sel ? [...sel.options].map((o) => ({ value: o.value, text: clean(o.textContent) })).filter((o) => o.value) : [];
}

function selectedClassValue(doc) {
  const sel = doc.querySelector(CLASS_SELECT);
  if (!sel) return "";
  const o = sel.querySelector("option[selected]") || sel.options[sel.selectedIndex];
  return o ? o.value : "";
}

// Sorts the cards into scored assignments, unscored ones ("blanks") and point-scale ones ("standards"),
// plus a short description of every card that wasn't a plain score (for debugging).
function readAssignments(doc) {
  const items = [];
  const blanks = [];
  const standards = [];
  const skipped = [];
  for (const card of doc.querySelectorAll(".GradebookDetailsTable .Card")) {
    const heading = card.querySelector(".TextHeading");
    const cat = card.querySelector(".TextSubSectionCategory");
    const scoreBox = card.querySelector('[id$="_scoreData"]');
    const spans = card.querySelectorAll('[id$="_scoreData"] .ScoreCard span');
    const name = clean(heading && heading.textContent).replace(/^\d+\s*-\s*/, "");
    const category = clean(cat && cat.textContent);
    const s = spans.length >= 3 ? parseScore(spans[0].textContent, spans[2].textContent) : { kind: "bad" };
    const text = clean(card.textContent).toLowerCase();
    const complete = /grading complete:\s*true/.test(text);
    const due = dueOf(card.textContent);
    if (name && category && s.kind === "normal") {
      items.push({ category, name, earned: s.earned, possible: s.possible, due });
      continue;
    }
    if (name && category && s.kind === "blank") blanks.push({ category, name, possible: s.possible, complete, due });
    else if (name && category && s.kind === "standards") standards.push({ category, name, earned: s.earned, possible: STANDARDS_SCALE, due });
    const tokens = new Set();
    if (s.kind === "bad") for (const el of card.querySelectorAll("*")) for (const t of classesOf(el)) tokens.add(t);
    skipped.push({
      kind: s.kind,
      scoreText: clean(scoreBox && scoreBox.textContent).slice(0, 40),
      complete,
      flags: FLAG_WORDS.filter((w) => text.includes(w)),
      cardClasses: [...tokens].slice(0, 25),
    });
  }
  // Cards with a hint of "missing" etc. matter most, so list those first.
  skipped.sort((x, y) => y.flags.length - x.flags.length);
  return { items, blanks, standards, skipped };
}

const rowCells = (row) => [...row.children].map((x) => clean(x.textContent));

function readCategories(doc) {
  const out = [];
  for (const row of doc.querySelectorAll("tr")) {
    const c = rowCells(row);
    if (c.length < 5 || /^total/i.test(c[0])) continue;
    if (!/^\d+(\.\d+)?%$/.test(c[1]) || !/%$/.test(c[4])) continue; // "Perc of Grade" and "Perc" columns
    out.push({ name: c[0], weight: num(c[1]), points: num(c[2]), max: num(c[3]), percent: num(c[4]), mark: c[5] || "" });
  }
  return out;
}

function readTotal(doc) {
  for (const row of doc.querySelectorAll("tr")) {
    const c = rowCells(row);
    if (/^total$/i.test(c[0] || "")) {
      const pct = c.slice(1).find((x) => /^\d+(\.\d+)?%$/.test(x));
      const avg = c.slice(1).find((x) => /^\d+(\.\d+)?$/.test(x));
      const last = c[c.length - 1] || "";
      return { percent: pct ? num(pct) : NaN, average: avg ? num(avg) : NaN, mark: /^[A-F][+-]?$/.test(last) ? last : "", cells: c.slice(0, 8) };
    }
  }
  return null;
}

// The grades section says e.g. "Min Score threshold is 50% and Max Score threshold is 100%" for "*" classes.
function readScale(doc, starred) {
  if (!starred) return null;
  const panel = doc.querySelector('[id$="_upEverything"]') || doc.body;
  const m = ((panel && panel.textContent) || "").match(/Min Score threshold is\s*(\d+(?:\.\d+)?)\s*%\s*and\s*Max Score threshold is\s*(\d+(?:\.\d+)?)\s*%/i);
  return m ? { min: Number(m[1]), max: Number(m[2]), found: true } : { min: 50, max: 100, found: false };
}

// Sentences in the grades section that mention a scale. Only used in the debug report, so a missing grading
// scale can be found. Short, and nothing else from the page.
function readScaleHints(doc) {
  const panel = doc.querySelector('[id$="_upEverything"]') || doc.body;
  const text = clean((panel && panel.textContent) || "");
  const out = [];
  for (const m of text.matchAll(/[^.!?]{0,100}\b(?:grading scale|grade scale|scale)\b[^.!?]{0,140}/gi)) {
    const t = clean(m[0]);
    if (t && !out.includes(t)) out.push(t);
    if (out.length >= 4) break;
  }
  return out;
}

function readTeacher(doc) {
  const el = doc.querySelector('[id$="_lblTeacherName"]');
  return el ? el.textContent : "";
}

// Structure only (class names and ids, no text), used when a class reads empty.
function describeStructure(doc) {
  const panel = doc.querySelector('[id$="_upEverything"]') || doc.body;
  const tokens = new Set();
  for (const el of panel.querySelectorAll("*")) {
    for (const t of classesOf(el)) tokens.add(t);
    if (tokens.size >= 90) break;
  }
  const tables = [...panel.querySelectorAll("table")].slice(0, 8).map((t) => ({
    id: (t.id || "").replace(/^.*?(subGBS_)/, "$1"),
    classes: classesOf(t),
    rows: t.querySelectorAll("tr").length,
  }));
  const toggles = [...panel.querySelectorAll("a,button,label,span,input")]
    .map((e) => clean(e.textContent || e.value))
    .filter((x) => /^(card|table) view$/i.test(x))
    .slice(0, 4);
  const ids = [...panel.querySelectorAll("[id]")].map((e) => e.id.replace(/^.*?(subGBS_)/, "$1")).slice(0, 40);
  return { classTokens: [...tokens], tables, toggles, ids, textLength: clean(panel.textContent).length };
}

// Turns one rendered gradebook page into the record Ledger imports, plus a debug description.
function classRecord(doc, optionText) {
  const a = readAssignments(doc);
  const cats = readCategories(doc);
  const total = readTotal(doc);
  const reported = total && Number.isFinite(total.percent) ? total.percent : null;
  const starred = /\*\s*$/.test(optionText); // "*": Aeries applies a minimum/maximum score to this class
  const scale = readScale(doc, starred);
  const notes = [];
  let items = a.items;
  let how = "graded only";
  let pickInfo = null;
  if (!items.length && a.standards.length) {
    items = a.standards;
    how = "point scale";
    notes.push(
      "This class is graded on a point scale (Aeries shows an average of " +
        (total && Number.isFinite(total.average) ? total.average.toFixed(2) : "?") +
        "). Ledger assumed a " + STANDARDS_SCALE + "-point scale. Check it against Aeries."
    );
  } else {
    const scaled = applyScale(a.items, scale);
    if (scaled.changed) {
      notes.push("Counted " + scaled.changed + " score" + (scaled.changed === 1 ? "" : "s") + " at Aeries' limit of " + scale.min + "% to " + scale.max + "%, like Aeries does.");
    }
    const pick = pickItems(cats, scaled.items, a.blanks, reported, scale);
    items = pick.list;
    how = pick.used;
    pickInfo = { counted: pick.zeros, off: pick.d === undefined ? null : Math.round(pick.d * 1000) / 1000 };
    if (pick.zeros) {
      notes.push(
        "Counted " + pick.zeros + " unscored assignment" + (pick.zeros === 1 ? "" : "s") +
          (scale ? " at the minimum score (" + scale.min + "%)" : " as 0") + " so the grade matches Aeries."
      );
    }
  }
  // A class graded by total points has no category weights, and Aeries then pools every assignment. That is different from
  // splitting the weight evenly between whichever categories the assignments are filed under. Try both and keep the one
  // that reproduces the percentage Aeries reports.
  let catsUsed = cats;
  if (!cats.length && items.length && reported != null && how !== "point scale") {
    const names = [...new Set(items.map((x) => x.category))];
    const even = names.map((n) => ({ name: n, weight: Math.round(10000 / names.length) / 100 }));
    const pooledCat = [{ name: "All assignments", weight: 100 }];
    const pooledItems = items.map((x) => ({ ...x, category: "All assignments" }));
    const pe = percentOf(even, items), pp = percentOf(pooledCat, pooledItems);
    if (pe != null && pp != null && Math.abs(pp - reported) < Math.abs(pe - reported) - 0.05) {
      catsUsed = pooledCat;
      items = pooledItems;
      how += " + pooled";
      notes.push("This class is graded by total points (no category weights), so Ledger counts all its assignments together.");
    }
  }

  // The (percent, letter) pairs Aeries gives for this class. They show which scale it uses (plus/minus or not).
  const marks = [];
  for (const k of cats) {
    if (/^[A-F][+-]?$/.test(k.mark || "") && Number.isFinite(k.percent) && k.max > 0) marks.push({ pct: k.percent, mark: k.mark });
  }
  if (total && /^[A-F][+-]?$/.test(total.mark || "")) {
    if (reported != null) marks.push({ pct: reported, mark: total.mark });
    else if (how === "point scale" && Number.isFinite(total.average)) marks.push({ pct: Math.round((total.average / STANDARDS_SCALE) * 10000) / 100, mark: total.mark });
  }
  const pending = a.blanks.map((b) => ({ category: b.category, name: b.name, possible: b.possible, complete: !!b.complete, due: b.due || null }));
  const cls = buildClass({ option: optionText, teacher: readTeacher(doc), assignments: items, categories: catsUsed, total, notes, marks, pending });
  const diag = {
    option: optionText,
    read: items.length,
    cards: cardCount(doc),
    categoriesFound: cats.length,
    categories: cats, // Aeries' own table: weight, points, max, percent
    ledgerByCategory: catsUsed.map((k) => {
      const xs = items.filter((x) => x.category === k.name);
      return {
        name: k.name,
        points: Math.round(xs.reduce((t, x) => t + x.earned, 0) * 1000) / 1000,
        max: xs.reduce((t, x) => t + x.possible, 0),
      };
    }),
    total: total ? total.cells : null,
    marks,
    scaleHints: readScaleHints(doc),
    retried: false,
    how,
    starred,
    scale,
    scored: a.items.length,
    blanks: a.blanks.length,
    standards: a.standards.length,
    pick: pickInfo,
    skippedSamples: a.skipped.slice(0, 4),
  };
  if (!items.length) diag.structure = describeStructure(doc);
  return { cls, diag, needsRetry: cardCount(doc) === 0 && cats.some((c) => c.max > 0) };
}

// ---------------------------------------------------------------------------
// Fast reading: ask the server for each class directly instead of flipping the page.
// Every answer is checked: the page must really be the class we asked for.
// ---------------------------------------------------------------------------

function fastDeps(deps) {
  return Object.assign({
    fetchFn: (url, opts) => fetch(url, opts),
    parse: (html) => new DOMParser().parseFromString(html, "text/html"),
  }, deps || {});
}

const looksLikeLogin = (url) => { try { return /login/i.test(new URL(url).pathname); } catch (e) { return false; } };

async function fastReadAll(base, credentials, deps) {
  const d = fastDeps(deps);
  const get = async (url) => {
    const res = await d.fetchFn(url, { credentials, redirect: "follow", cache: "no-store" });
    const html = await res.text();
    return { finalUrl: res.url || url, status: res.status, doc: d.parse(html) };
  };
  const first = await get(base + "GradebookDetails.aspx");
  if (looksLikeLogin(first.finalUrl)) return { ok: false, reason: "login" };
  const options = classOptions(first.doc);
  const firstValue = selectedClassValue(first.doc);
  if (!options.length || !firstValue) return { ok: false, reason: "fail", detail: "gradebook page not recognized (HTTP " + first.status + ")" };

  const pages = new Map();
  pages.set(firstValue, first.doc);
  for (const o of options) {
    if (pages.has(o.value)) continue;
    // Option values look like "GradebookNumber_Term_CDS_SC", the same pieces Aeries' own dashboard links use.
    const parts = o.value.split("_");
    if (parts.length !== 4) return { ok: false, reason: "fail", detail: "unexpected class id format" };
    const q = "GradebookNumber=" + encodeURIComponent(parts[0]) + "&Term=" + encodeURIComponent(parts[1]) +
      "&CDS=" + encodeURIComponent(parts[2]) + "&SC=" + encodeURIComponent(parts[3]);
    let page = await get(base + "Widgets/ClassSummary/RedirectToGradebook?" + q);
    if (looksLikeLogin(page.finalUrl)) return { ok: false, reason: "login" };
    if (selectedClassValue(page.doc) !== o.value) {
      // some portals only record the choice and show it on the next page load
      page = await get(base + "GradebookDetails.aspx");
      if (looksLikeLogin(page.finalUrl)) return { ok: false, reason: "login" };
    }
    if (selectedClassValue(page.doc) !== o.value) return { ok: false, reason: "fail", detail: "couldn't open " + o.text };
    pages.set(o.value, page.doc);
  }

  const classes = [];
  const diag = [];
  for (const o of options) {
    const rec = classRecord(pages.get(o.value), o.text);
    rec.diag.method = "fast";
    classes.push(rec.cls);
    diag.push(rec.diag);
  }
  return { ok: true, payload: { version: 1, host: new URL(base).hostname, base: new URL(base).pathname, readAt: new Date().toISOString(), classes }, diag };
}

// One cheap request that changes whenever a grade on the dashboard changes. Null if the dashboard
// doesn't contain grades in its page source (some are filled in later by script).
async function probeSignature(base, credentials, deps) {
  const d = fastDeps(deps);
  const res = await d.fetchFn(base + "Dashboard.aspx", { credentials, redirect: "follow", cache: "no-store" });
  const html = await res.text();
  if (looksLikeLogin(res.url || base)) return { ok: false, reason: "login" };
  const doc = d.parse(html);
  const text = (doc.body && doc.body.textContent) || "";
  const m = text.match(/\(\s*(?:\d+(?:\.\d+)?\s*%|\d+(?:\.\d+)?\s*Avg)\s*\)/g);
  return { ok: true, sig: m && m.length ? m.map((x) => x.replace(/\s+/g, "")).join("|") : null };
}

// ---------------------------------------------------------------------------
// Noticing new and changed grades (used for desktop alerts)
// ---------------------------------------------------------------------------

// A compact list of every scored assignment, to compare one read with the next.
function snapshotOf(payload) {
  const out = [];
  for (const c of payload.classes) for (const a of c.assignments) out.push({ c: c.name, g: a.category, n: a.name, e: a.earned, p: a.possible });
  return out;
}

// What is new or different in `next` compared with `prev`.
function diffSnapshots(prev, next) {
  const key = (x) => x.c + "|" + x.g + "|" + x.n;
  const seen = new Map();
  for (const x of prev) { const k = key(x); if (!seen.has(k)) seen.set(k, []); seen.get(k).push(x); }
  const changes = [];
  for (const x of next) {
    const hit = (seen.get(key(x)) || []).shift();
    if (!hit) changes.push({ kind: "new", cls: x.c, name: x.n, earned: x.e, possible: x.p });
    else if (hit.e !== x.e || hit.p !== x.p) changes.push({ kind: "changed", cls: x.c, name: x.n, earned: x.e, possible: x.p, from: hit.e });
  }
  return changes;
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    clean, num, parseOption, levelFor, teacherName, buildClass, parseScore, percentOf, applyScale, pickItems, STANDARDS_SCALE,
    readAssignments, readCategories, readTotal, readScale, readTeacher, describeStructure, classOptions, selectedClassValue,
    classRecord, cardCount, fastReadAll, probeSignature, looksLikeLogin, readScaleHints, parseUsDate, dueOf, snapshotOf, diffSnapshots,
  };
}
