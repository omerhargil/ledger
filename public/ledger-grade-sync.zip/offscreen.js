// Ledger Importer: offscreen reader. A hidden page the background worker uses (workers have no DOM parser).
// It asks Aeries for the gradebook pages with your existing Aeries session, parses them, and sends back the grades.
// It never sees your password: it only uses the cookies your browser already has for aeries.net.

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.target !== "offscreen") return false;
  // Only ever talk to the student portal of an aeries.net address.
  const ok = typeof msg.base === "string" && /^https:\/\/[a-z0-9-]+(\.[a-z0-9-]+)*\.aeries\.net(\/[A-Za-z0-9_.\-]+)+\/$/i.test(msg.base) && !/\.\./.test(msg.base);
  if (!ok) { sendResponse({ ok: false, reason: "fail", detail: "bad address" }); return false; }
  const run = msg.type === "offscreen:read" ? fastReadAll(msg.base, "include")
    : msg.type === "offscreen:probe" ? probeSignature(msg.base, "include")
    : null;
  if (!run) return false;
  run.then(sendResponse, (e) => sendResponse({ ok: false, reason: "fail", detail: String((e && e.message) || e).slice(0, 200) }));
  return true; // answer comes later
});
