// Ledger Importer: page script. Runs only on https://*.aeries.net/student/* pages (reader.js is loaded first).
//
// On Gradebook Details it adds a button that sends your grades to your Ledger app. It also reads by itself when
// Ledger's background worker opened the tab for that purpose. It reads: class names, teachers, grade categories
// and weights, assignment names and scores. It never reads your name, ID numbers, birthdate or contact details.
// The grades go only to LEDGER_URL below.

(() => {
  "use strict";
  if (typeof document === "undefined") return;

  // Where your Ledger app runs. Change this if you host it somewhere else.
  const LEDGER_URL = "https://ledgergrades.vercel.app/";
  const LEDGER_ORIGIN = new URL(LEDGER_URL).origin;

  if (!/\/gradebookdetails\.aspx$/i.test(location.pathname)) return;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const classSelect = () => document.querySelector(CLASS_SELECT);

  // --- reading: fast path first, then the slow one ---------------------------

  // Wait until the number of cards stops changing (the page can finish drawing after the swap).
  async function settle() {
    let prev = -1;
    let same = 0;
    for (let i = 0; i < 20 && same < 2; i++) {
      const n = cardCount(document);
      same = n === prev ? same + 1 : 0;
      prev = n;
      await sleep(400);
    }
  }

  // Aeries swaps the class by reloading part of the page, so wait for that to settle.
  async function switchTo(value) {
    const sel = classSelect();
    if (!sel) throw new Error("Couldn't find the class list.");
    if (sel.value === value) return;
    const root = document.querySelector('[id$="_upEverything"]') || document.body;
    let changed = false;
    let last = Date.now();
    const mo = new MutationObserver(() => { changed = true; last = Date.now(); });
    mo.observe(root, { childList: true, subtree: true, characterData: true });
    sel.value = value;
    sel.dispatchEvent(new Event("change", { bubbles: true }));
    const start = Date.now();
    try {
      while (Date.now() - start < 25000) {
        await sleep(150);
        const cur = classSelect();
        if (changed && Date.now() - last > 600 && cur && cur.value === value) return;
      }
      throw new Error("Aeries took too long to switch classes.");
    } finally {
      mo.disconnect();
    }
  }

  // The slow way: make the page itself flip through the classes, one by one.
  async function readAllSlow(onProgress, fastNote) {
    const options = classOptions(document);
    const original = classSelect().value;
    const classes = [];
    const diag = [];
    for (let i = 0; i < options.length; i++) {
      onProgress(i + 1, options.length);
      await switchTo(options[i].value);
      await settle();
      let rec = classRecord(document, options[i].text);
      let retried = false;
      // Aeries shows graded points for this class but no cards have appeared: give the page more time, once.
      if (rec.needsRetry) {
        retried = true;
        await sleep(2000);
        await settle();
        rec = classRecord(document, options[i].text);
      }
      rec.diag.retried = retried;
      rec.diag.method = "slow";
      if (fastNote) rec.diag.fastPathFailed = fastNote;
      classes.push(rec.cls);
      diag.push(rec.diag);
    }
    try { await switchTo(original); } catch (e) { /* leave the page where it is */ }
    return { payload: { version: 1, host: location.hostname, base: location.pathname.replace(/[^/]*$/, ""), readAt: new Date().toISOString(), classes }, diag };
  }

  async function readAllClasses(onProgress) {
    let fastNote = "";
    try {
      onProgress(0, 0);
      const base = location.origin + location.pathname.replace(/[^/]*$/, "");
      const fast = await fastReadAll(base, "same-origin");
      if (fast.ok) return { payload: fast.payload, diag: fast.diag };
      fastNote = fast.reason + (fast.detail ? ": " + fast.detail : "");
    } catch (e) {
      fastNote = "error: " + (e && e.message ? e.message : "unknown");
    }
    return readAllSlow(onProgress, fastNote);
  }

  // --- handing the grades to Ledger ------------------------------------------

  function openLedger(payload, diag, onSent, onTimeout) {
    const w = window.open(LEDGER_URL, "ledger-app");
    if (!w) { onTimeout("blocked"); return; }
    let done = false;
    const onMsg = (ev) => {
      if (ev.origin !== LEDGER_ORIGIN || !ev.data || ev.data.type !== "ledger:ready") return;
      done = true;
      window.removeEventListener("message", onMsg);
      w.postMessage({ type: "ledger:import", payload, diag }, LEDGER_ORIGIN);
      onSent();
    };
    window.addEventListener("message", onMsg);
    setTimeout(() => {
      if (done) return;
      window.removeEventListener("message", onMsg);
      onTimeout("silent");
    }, 12000);
  }

  // --- the buttons ------------------------------------------------------------

  const baseStyle = {
    position: "fixed", right: "18px", zIndex: "2147483647", border: "none", borderRadius: "10px",
    cursor: "pointer", font: "600 13px system-ui, sans-serif", maxWidth: "320px", textAlign: "left", lineHeight: "1.35",
  };

  function mount() {
    if (document.getElementById("ledger-importer-btn")) return;

    const btn = document.createElement("button");
    btn.id = "ledger-importer-btn";
    btn.type = "button";
    Object.assign(btn.style, baseStyle, {
      bottom: "18px", padding: "11px 16px", background: "#1B3A2F", color: "#fff", boxShadow: "0 6px 18px rgba(0,0,0,.25)",
    });
    document.body.appendChild(btn);

    const dbg = document.createElement("button");
    dbg.id = "ledger-importer-debug";
    dbg.type = "button";
    dbg.textContent = "Copy debug info";
    Object.assign(dbg.style, baseStyle, {
      bottom: "72px", padding: "6px 10px", background: "#fff", color: "#1B3A2F", border: "1px solid #1B3A2F",
      font: "500 11.5px system-ui, sans-serif", display: "none",
    });
    document.body.appendChild(dbg);

    let state = "idle";
    let payload = null;
    let diag = null;
    const show = (label, st, busy) => {
      state = st;
      btn.textContent = label;
      btn.disabled = !!busy;
      btn.style.opacity = busy ? "0.8" : "1";
      btn.style.cursor = busy ? "default" : "pointer";
    };
    show("Read my grades for Ledger", "idle");

    dbg.addEventListener("click", async () => {
      try {
        const text = JSON.stringify({ ledgerImporterDebug: { version: "0.6", classes: diag } }, null, 1);
        await navigator.clipboard.writeText(text);
        dbg.textContent = "Copied.";
      } catch (err) {
        console.log("Ledger Importer debug info:", diag);
        dbg.textContent = "Couldn't copy. It's in the console (F12).";
      }
      setTimeout(() => { dbg.textContent = "Copy debug info"; }, 3500);
    });

    btn.addEventListener("click", async () => {
      if (state === "idle" || state === "done" || state === "error") {
        const ok = confirm(
          "Ledger Importer will read each of your classes on this page.\n\n" +
          "It collects only class names, teachers, grade categories and scores, and sends them only to Ledger at " + LEDGER_ORIGIN + ".\n\nContinue?"
        );
        if (!ok) return;
        try {
          show("Reading…", "reading", true);
          const r = await readAllClasses((i, n) => show(n ? "Reading class " + i + " of " + n + "…" : "Reading…", "reading", true));
          payload = r.payload;
          diag = r.diag;
          dbg.style.display = "block";
          const graded = payload.classes.reduce((s, c) => s + c.assignments.length, 0);
          const warned = payload.classes.filter((c) => c.warnings.length).length;
          show(
            "Open Ledger with " + payload.classes.length + " classes (" + graded + " assignments)" +
              (warned ? ". " + warned + (warned === 1 ? " class has" : " classes have") + " a warning." : ""),
            "ready"
          );
        } catch (err) {
          console.error("Ledger Importer:", err);
          show("Couldn't read your grades: " + (err && err.message ? err.message : "unknown error") + " Click to try again.", "error");
        }
        return;
      }

      if (state === "ready") {
        show("Waiting for Ledger…", "waiting", true);
        openLedger(
          payload,
          diag,
          () => show("Sent. Confirm the import in the Ledger tab.", "done"),
          (why) => show(
            why === "blocked"
              ? "Your browser blocked the Ledger tab. Allow pop-ups for this site, then click here."
              : "Ledger didn't answer. Is it running at " + LEDGER_ORIGIN + "? Click to copy the grades instead.",
            why === "blocked" ? "ready" : "fallback"
          )
        );
        return;
      }

      if (state === "fallback") {
        try {
          await navigator.clipboard.writeText(JSON.stringify({ ledgerImport: payload }));
          show("Copied. Open Ledger and press Cmd+V (or Ctrl+V).", "done");
        } catch (err) {
          show("Couldn't copy to the clipboard.", "error");
        }
      }
    });
  }

  // --- the background worker's own tab ------------------------------------------

  const toBackground = (m) => { try { chrome.runtime.sendMessage(m); } catch (e) { /* extension was reloaded */ } };

  // Is this a tab Ledger opened (so it should read by itself), or a tab the person is using?
  function isLedgerJob() {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ type: "ledger:aux-hello" }, (r) => {
          void chrome.runtime.lastError; // no answer just means "not a job"
          resolve(!!(r && r.auto));
        });
      } catch (e) { resolve(false); }
    });
  }

  async function autoRun() {
    try {
      toBackground({ type: "ledger:aux-progress", i: 0, n: 0 });
      const r = await readAllClasses((i, n) => toBackground({ type: "ledger:aux-progress", i, n }));
      toBackground({ type: "ledger:aux-grades", payload: r.payload, diag: r.diag });
    } catch (err) {
      toBackground({ type: "ledger:aux-error", message: err && err.message ? err.message : "unknown error" });
    }
  }

  (async () => {
    const auto = await isLedgerJob();
    for (let i = 0; i < 40 && !classSelect(); i++) await sleep(500);
    if (!classSelect()) {
      if (auto) toBackground({ type: "ledger:aux-error", message: "The gradebook didn't load." });
      return;
    }
    if (auto) autoRun(); // in this mode the tab is just a worker, so no button
    else mount();
  })();
})();
