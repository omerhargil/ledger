// Ledger Importer: bridge. Runs only on the Ledger page (see "matches" in manifest.json).
// Passes messages between the Ledger page and the extension's background worker.
// Ledger -> extension: ledger:req-ping, ledger:req-refresh {host, mode}, ledger:req-cancel, ledger:req-alerts {host, on}
// extension -> Ledger: ledger:ext-ready, ledger:ext-status {phase, detail}, ledger:ext-result {payload}

(() => {
  "use strict";
  if (typeof window === "undefined" || typeof chrome === "undefined" || !chrome.runtime) return;
  const VERSION = "0.9";
  const origin = window.location.origin;
  const toLedger = (m) => window.postMessage(m, origin);
  const toBackground = (m) => { try { chrome.runtime.sendMessage(m); } catch (e) { /* extension was reloaded */ } };

  window.addEventListener("message", (ev) => {
    // Only the Ledger page itself may talk to the extension.
    if (ev.source !== window || ev.origin !== origin) return;
    const d = ev.data;
    if (!d || typeof d.type !== "string") return;
    if (d.type === "ledger:req-ping") toLedger({ type: "ledger:ext-ready", version: VERSION });
    else if (d.type === "ledger:req-refresh" && typeof d.host === "string") toBackground({ type: "ledger:refresh", host: d.host.slice(0, 120), mode: d.mode === "silent" ? "silent" : "manual", base: typeof d.base === "string" ? d.base.slice(0, 80) : "", force: d.force === true });
    else if (d.type === "ledger:req-cancel") toBackground({ type: "ledger:cancel" });
    else if (d.type === "ledger:req-alerts" && typeof d.host === "string") toBackground({ type: "ledger:alerts", host: d.host.slice(0, 120), on: d.on === true, base: typeof d.base === "string" ? d.base.slice(0, 80) : "" });
  });

  try {
    chrome.runtime.onMessage.addListener((m) => {
      if (!m || (m.type !== "ledger:ext-status" && m.type !== "ledger:ext-result")) return;
      toLedger(m);
    });
  } catch (e) { /* extension was reloaded */ }

  toLedger({ type: "ledger:ext-ready", version: VERSION });
})();
